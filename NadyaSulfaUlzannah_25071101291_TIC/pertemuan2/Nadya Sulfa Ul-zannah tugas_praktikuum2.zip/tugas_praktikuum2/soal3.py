tim_frontend = {"HTML", "CSS", "JavaScript", "Reatct"}
tim_backend = {"Python", "JavaScript", "SQL", "NodeJS"}

