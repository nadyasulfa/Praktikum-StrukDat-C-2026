barang = ("B001", "Laptop Gaming", 15000000)

print(barang[2])

y = list(barang)
y[2] = 14000000
barang = tuple(y)
print(barang)

(kode, nama, harga) = barang
print(kode)
print(nama)
print(harga)